function getRichEdit()
{
var theEditor="";
theEditor+='<table bgcolor="#C0C0C0" id="toolbar1">\n';
theEditor+='<tr>\n';
theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="cut"><img class="image" src="cut.gif" alt="Cut" title="Cut"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="copy"><img class="image" src="copy.gif" alt="Copy" title="Copy"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="paste"><img class="image" src="paste.gif" alt="Paste" title="Paste"></div>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="undo"><img class="image" src="undo.gif" alt="Undo" title="Undo"></div>\n';

theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="redo"><img class="image" src="redo.gif" alt="Redo" title="Redo"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 10px;" class="imagebutton" id="createlink"><img class="image" src="link.gif" alt="Insert Link" title="Insert Link"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 10px;" class="imagebutton" id="createimage"><img class="image" src="image.gif" alt="Insert Image" title="Insert Image"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 10px;" class="imagebutton" id="createtable"><img class="image" src="table.gif" alt="Insert Table" title="Insert Table"></div>\n';
theEditor+='</td>\n';

theEditor+='</tr>\n';
theEditor+='</table>\n';
theEditor+='<br>\n';
theEditor+='<table bgcolor="#C0C0C0" id="toolbar2">\n';
theEditor+='<tr>\n';
theEditor+='<td>\n';
theEditor+='<select id="formatblock" onchange="Select(this.id);">\n';
theEditor+='  <option value="<p>">Normal</option>\n';
theEditor+='  <option value="<p>">Paragraph</option>\n';
theEditor+='  <option value="<h1>">Heading 1 <H1></option>\n';
theEditor+='  <option value="<h2>">Heading 2 <H2></option>\n';
theEditor+='  <option value="<h3>">Heading 3 <H3></option>\n';
theEditor+='  <option value="<h4>">Heading 4 <H4></option>\n';
theEditor+='  <option value="<h5>">Heading 5 <H5></option>\n';
theEditor+='  <option value="<h6>">Heading 6 <H6></option>\n';
theEditor+='  <option value="<address>">Address <ADDR></option>\n';
theEditor+='  <option value="<pre>">Formatted <PRE></option>\n';

theEditor+='</select>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<select id="fontname" onchange="Select(this.id);">\n';
  theEditor+='<option value="Font">Font</option>\n';
  theEditor+='<option value="Arial">Arial</option>\n';
  theEditor+='<option value="Courier">Courier</option>\n';
  theEditor+='<option value="Times New Roman">Times New Roman</option>\n';
theEditor+='</select>\n';

theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<select unselectable="on" id="fontsize" onchange="Select(this.id);">\n';
  theEditor+='<option value="Size">Size</option>\n';
  theEditor+='<option value="1">1</option>\n';
  theEditor+='<option value="2">2</option>\n';
  theEditor+='<option value="3">3</option>\n';
  theEditor+='<option value="4">4</option>\n';

theEditor+='  <option value="5">5</option>\n';
theEditor+='  <option value="6">6</option>\n';
  theEditor+='<option value="7">7</option>  \n';
theEditor+='</select>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="bold"><img class="image" src="bold.gif" alt="Bold" title="Bold"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="italic"><img class="image" src="italic.gif" alt="Italic" title="Italic"></div>\n';
theEditor+='</td>\n';

theEditor+='<td>\n';
theEditor+='<div class="imagebutton" id="underline"><img class="image" src="underline.gif" alt="Underline" title="Underline"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 10px;" class="imagebutton" id="forecolor"><img class="image" src="forecolor.gif" alt="Text Color" title="Text Color"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 40px;" class="imagebutton" id="hilitecolor"><img class="image" src="backcolor.gif" alt="Background Color" title="Background Color"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 10px;" class="imagebutton" id="justifyleft"><img class="image" src="justifyleft.gif" alt="Align Left" title="Align Left"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';

theEditor+='<div style="left: 40px;" class="imagebutton" id="justifycenter"><img class="image" src="justifycenter.gif" alt="Center" title="Center"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 70px;" class="imagebutton" id="justifyright"><img class="image" src="justifyright.gif" alt="Align Right" title="Align Right"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 10px;" class="imagebutton" id="insertorderedlist"><img class="image" src="orderedlist.gif" alt="Ordered List" title="Ordered List"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 40px;" class="imagebutton" id="insertunorderedlist"><img class="image" src="unorderedlist.gif" alt="Unordered List" title="Unordered List"></div>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 10px;" class="imagebutton" id="outdent"><img class="image" src="outdent.gif" alt="Outdent" title="Outdent"></div>\n';

theEditor+='</td>\n';
theEditor+='<td>\n';
theEditor+='<div style="left: 40px;" class="imagebutton" id="indent"><img class="image" src="indent.gif" alt="Indent" title="Indent"></div>\n';
theEditor+='</td>\n';
theEditor+='</tr>\n';
theEditor+='</table>\n';
theEditor+='<br>\n';
//theEditor+='<iframe id="edit" width="100%" height="200px"></iframe>\n';
theEditor+='<iframe width="250px" height="170px" id="colorpalette" src="colors.html" style="visibility:hidden; position: absolute;"></iframe>\n';


//theEditor+='<input type="checkbox" onclick="viewsource(this.checked)">\n';
//theEditor+='View HTML Source</input>\n';

theEditor+='<input checked type="checkbox" onclick="usecss(this.checked)">\n';
theEditor+='Use CSS:</input>\n';
//theEditor+='<input type="checkbox" onclick="readonly(this.checked)">\n';
//theEditor+='Read only</input>\n';
theEditor+=' Selected ID:<input type="text" disabled=true id="whatIsSelected" value="" \>\n';
theEditor+='<br />Make Editable?:<input type="checkbox" id="canEditYN" onclick="makeEditable(this.checked)" \>Hold Ctrl while in edit mode to move objects\n';
 
theEditor+='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://validator.w3.org/check?uri=referer"><img style="border:0px" src="http://www.w3.org/Icons/valid-html401" alt="Valid HTML 4.01 Transitional" height="18" width="50"></a>';


return theEditor;
}

function getPropsWin()
{
var buildWindow=""

buildWindow+= '<table style="border:0" id="propTable">\n ';

	buildWindow+=' <tr>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+='Distance from Top:\n ';
		buildWindow+=' </td>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+=' <input type="text" id="propTop" style="width:50px" onchange="changeProp(this.id)"/>\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';
	
	buildWindow+=' <tr>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+='		Distance from Left:\n ';
		buildWindow+=' </td>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+=' <input type="text" id="propLeft" style="width:50px" onchange="changeProp(this.id)" />\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';
	
	buildWindow+=' <tr>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+='Height:\n ';
		buildWindow+=' </td>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+=' <input type="text" id="propHeight" style="width:50px" onchange="changeProp(this.id)" />\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';
	
	buildWindow+=' <tr>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+='Width:\n ';
		buildWindow+=' </td>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+=' <input type="text" id="propWidth" style="width:50px" onchange="changeProp(this.id)" />\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';
	
	buildWindow+=' <tr>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+='Source:\n ';
		buildWindow+=' </td>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+=' <input type="text" id="propSrc" style="width:250px" onchange="changeProp(this.id)" />\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';
	
	buildWindow+=' <tr>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+='Transparancy/Opacity%\n ';
		buildWindow+=' </td>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+=' <input type="text" id="propOpacity" style="width:50px" onchange="changeProp(this.id)" />\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';	

	buildWindow+=' <tr>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+='Selected Object\n ';
		buildWindow+=' </td>\n ';
		buildWindow+=' <td >\n ';
		buildWindow+=' <input type="text" disabled id="propSelectedObject" style="width:150px" />\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';	
	
	buildWindow+=' <tr>\n ';
		buildWindow+=' <td style="text-align:center">\n ';
		buildWindow+=' <input type="button" value="Update Info" onclick="updateProps()"/>\n ';
		if(IE)
			buildWindow+=' <input type="button" value="Apply Changes" onclick=""/>\n ';
		buildWindow+=' </td>\n ';
	buildWindow+=' </tr>\n ';
buildWindow+=' </table>\n ';

return buildWindow;

}