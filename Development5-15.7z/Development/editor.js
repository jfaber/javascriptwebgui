/*
					By:				    Jeffrey E. Faber
					Purpose: 			Creates and manipulates objects on an HTML page.
					Date Started: 		May 11th, 2010
					Date Completed:		*
					Version:			1.0
					Required libs:		windowSys.js, menuSys.js, richText.js
*/

var idInc=1; // This value makes sure each object has a unique ID
var selectedObject=""; // Global selected object
var objectCanMove=false; //Checks to see if Shift is pressed, if so allow movement.
document.onkeydown = getKey; //Gets key codes on key Down
document.onkeyup = keyDone;  // Gets key codes on key Up
 // sets moveHandler for getting mouseOver


function getClickID(mEvent)
{
	//Standard Meathod
	if (mEvent.target)
	{	
		theMouseOver=mEvent.target;
	}
	// IE rig
	else if (mEvent.srcElement)
	{
		theMouseOver=mEvent.srcElement;
	}


}
//------------------------------Key Press Capture----------------------------------
function getKey(key)
{
//16 is shift, 17 is crtl, 18 is alt.
var pressedKey = (window.event) ? event.keyCode : key.keyCode;

 if(pressedKey==17)
  objectCanMove=true;
}
function keyDone(key)
{
var pressedKey = (window.event) ? event.keyCode : key.keyCode;

 if(pressedKey==17)
  objectCanMove=false;
}

//--------------------------------Sets up the Window for the Rich text Editor--------------------------------
function openRichEdit(theID)
{
objectInEdit=theID;
if(!document.getElementById("editorWindow"))
createDetailedWindow(200, 200, 658, 147, "Text Editor", "#000000", "#4444FF", true, true, false, true, "#3333FF", "#000000", "#C0C0C0", "#000000", getRichEdit(), "editorWindow");
//createDetailedWindow(startingLeft, startingTop, startingWidth, startingHeight, topTitle, titleColor, titleBGColor, canClose, canMin, canResize, canMove, titleButtonBGColor, titleButtonTextColor, textBGColor, textColor, innerCode, windowID)
}

//--------------------------------Initiates the Menu--------------------------------------

/*
Syntax:
addMenu(menuName, silent);   Adds new main menu
function addSub(menuToAdd,subName,subAction, silent);   Adds new sub menu, the menuToAdd is 0 at the left most and increments by one.
*/

function setUpMenu()
{
addMenu("File",true);
addMenu("Insert",true);
addMenu("Edit",true);

addMenu('<input type="text" value="no selection" disabled style="width:150px" id="theSelected" />',true);
codeNeeded="<span onclick=\"setMenu();closeWindow('menuClosed') \">Click here to re-open the menu.</span>";

//---------------------File----------------------
addSub(0,"Close Menu", "killMenu();createDetailedWindow(100, 100, 100, 100, 'Click to Open Menu', '000000', '#4444FF', false, false, false, true, '#3333FF', '#000000', '#FFFFFF', '#000000',codeNeeded , 'menuClosed')", true);
addSub(0,"Finish&Save", "completePage()", true);
addSub(0,"Blank", "", true);

//---------------------Insert--------------------
addSub(1,"Div","createObject('div','object'+idInc);", true);
addSub(1,"Span","createObject('span','object'+idInc);", true);
addSub(1,"Image","createObject('img','object'+idInc);", true);

//----------------------Edit----------------------
addSub(2, "Page Title", "document.title=prompt('Enter a New Page Title',document.title);", true);
addSub(2, "Properties", "openProperties();", true);
addSub(2,"Blank", "", true);


setMenu(); // just places menu
}

//--------------------------------Select Object---------------------------------------

/*
This is fowarded from selctObjectE(theID) to prevent errors when edit mode is disabled.
*/
function selectObject(theID)
{
selectedObject=theID; //Select the clicked object.
document.getElementById("theSelected").value=theID;
var objType=document.getElementById(theID).nodeName; //See what said object is and take appropriate actions below
if(objType=="DIV"||objType=="SPAN") //if it's an object with editable content
	{
	openRichEdit(theID);
	Start();
	document.getElementById("whatIsSelected").value=theID;
	document.getElementById(document.getElementById("whatIsSelected").value).contentEditable=document.getElementById("canEditYN").checked;
	}
if(objType=="IMG") // if it's an image
	{
	openRichEdit(theID);
	Start();
	document.getElementById("whatIsSelected").value=theID;
	}

// if shift is pressed(objectCanMove) and our edit box is checked then allow movement.
if(objectCanMove&&document.getElementById("canEditYN").checked)
	moveObject(theID);
}

//-------------------------------------------- makeEditable --------------------------
/*
This little guy just changes if the object can be edited.
*/

function makeEditable(isEdit)
{
if(isEdit)
	document.getElementById(document.getElementById("whatIsSelected").value).designMode="on";
else
	document.getElementById(document.getElementById("whatIsSelected").value).designMode="off";
}


//--------------------------------------Create Object--------------------------------
/*
Creates an object and, based on type, assignes attributes.
*/
function createObject(objectType,objectID)
{
//Check to see if the objectID is in use already, if it is halt.
if(document.getElementById(objectID))
	alert("Error: That objectID is in use already.");
else
	{	
	//create new object and set paramaters
	var newObject = document.createElement(objectType);
	
	newObject.id=objectID;
	newObject.style.position="absolute";
	newObject.style.left=150+"px";
	newObject.style.top=150+"px";
	//set type specific paramaters
	if(objectType=="div"||objectType=="span")
		{
		newObject.innerHTML=objectID;
		newObject.contenteditable=true;
		}
	else if(objectType="img")
		{
		newObject.src=prompt('Please enter a path for the image.','http://');		
		}
	
	//drop object into the body
	document.body.appendChild(newObject);	

	//set the onclick to select this item
	if(!IE)
		document.getElementById(objectID).setAttribute("onmousedown","selectObjectE(this.id);");
	else
		document.getElementById(objectID).onmousedown=function(){selectObjectE(objectID)};
	
	//and increment the ID index
	idInc++;
	}
}

//----------------------------------Move Object----------------------------------
function moveObject(theID)
//Sets the initial values for moving the object relative the location of the mouse.
{
movingID=theID;
windowMoving=true;
judgex=document.getElementById(movingID).style.left.replace("px","")*1-posx;
judgey=document.getElementById(movingID).style.top.replace("px","")*1-posy;
}

//----------------------------Object Properties----------------------------------

function openProperties()
{
/*
This function displays and allows changing the object's properties depending on the type.
*/

if(selectedObject!=""&&selectedObject!="undefined"&& !document.getElementById("objectProps"))
	{
	createDetailedWindow(700, 20, 250, 10, selectedObject+" Properties", '#000000', '#4444FF', true, true, true, true, '#3333FF', '#000000', '#FFFFFF', '#000000', getPropsWin() , 'objectProps');
	document.getElementById("propSelectedObject").value=selectedObject;
	updateProps();
	document.getElementById("objectPropsBody").style.height=(document.getElementById("propTable").offsetHeight+10)+"px";

	
	}
}

function changeProp(get)
{
//changes all properties for object on change
get=(get.replace("prop","")).toLowerCase();
document.getElementById(selectedObject).style.top=document.getElementById("propTop").value+"px";
document.getElementById(selectedObject).style.left=document.getElementById("propLeft").value+"px";
document.getElementById(selectedObject).style.width=document.getElementById("propWidth").value+"px";
document.getElementById(selectedObject).style.height=document.getElementById("propHeight").value+"px";
if(document.getElementById(selectedObject).nodeName=="IMG")
	document.getElementById(selectedObject).src=document.getElementById("propSrc").value;

	if(!document.getElementById("propOpacity").value)
		document.getElementById("propOpacity").value=100;
	document.getElementById(selectedObject).style.opacity=document.getElementById("propOpacity").value/100;

	document.getElementById(selectedObject).style.filter="alpha(opacity="+document.getElementById("propOpacity").value+")";

}

function updateProps()
{
//updates props on prop win from object
document.getElementById("propTop").value=document.getElementById(selectedObject).style.top.replace("px","");
document.getElementById("propLeft").value=document.getElementById(selectedObject).style.left.replace("px","");
document.getElementById("propWidth").value=document.getElementById(selectedObject).style.width.replace("px","");
document.getElementById("propHeight").value=document.getElementById(selectedObject).style.height.replace("px","");
if(document.getElementById(selectedObject).nodeName=="IMG")
	document.getElementById("propSrc").value=document.getElementById(selectedObject).src;
if(!IE)
	document.getElementById("propOpacity").value=document.getElementById(selectedObject).style.opacity;
else 
	document.getElementById("propOpacity").value=document.getElementById(selectedObject).style.filter.replace("alpha(opacity=","").replace(")","");


}

//---------------------------------Finalize and Save-------------------------------

function completePage()
{
/*
Cuts the Crap and outputs the code,

TODO:
	Add required Javascript to the save.
	Add W3 Complience to new code.

*/


var saveString="";
killMenu();
if(document.getElementById('subMenu')){document.body.removeChild(document.getElementById('subMenu'))}
closeWindow("editorWindow");
closeWindow("objectProps");
closeWindow("menuClosed");

saveString+="<html>\n<head>\n<title>"+document.title+"</title>\n</head>\n<body>\n";
saveString+=document.body.innerHTML;
saveString+="\n</body>\n</html>"
saveString=saveString.replace('contenteditable=\"true\"',"");
//createSimpleWindow('Copy This','<input type=text value="'+saveString+'"/>','theHTMLWin');

	createSimpleWindow('Copy This','Copy the code below into notepad and save as (File Name Here).htm<br /><textarea rows="9"  cols="34">'+saveString+'</textarea>','theHTMLWin');

setMenu();
}